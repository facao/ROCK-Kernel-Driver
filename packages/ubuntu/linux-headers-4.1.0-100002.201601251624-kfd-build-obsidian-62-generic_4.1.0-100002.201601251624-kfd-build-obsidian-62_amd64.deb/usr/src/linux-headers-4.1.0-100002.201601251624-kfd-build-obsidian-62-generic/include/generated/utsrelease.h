#define UTS_RELEASE "4.1.0-100002.201601251624-kfd-build-obsidian-62-generic"
#define UTS_UBUNTU_RELEASE_ABI 62
